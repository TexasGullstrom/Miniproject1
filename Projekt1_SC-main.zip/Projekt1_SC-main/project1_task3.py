import numpy as np 
import matplotlib.pyplot as plt

def PropensityFunc(State,ReactNo):
    # State: state variable [F,R]
    # ReactNo: number of reactions
    w = np.zeros(ReactNo)
    A,R,C,D_A,D_R,D_A_prime,D_R_prime,M_A,M_R = State
    w[0] = gamma_C*A*R
    w[1] = delta_A*A
    w[2] = delta_A*C
    w[3] = delta_R*R
    w[4] = gamma_A*D_A*A
    w[5] = gamma_R*D_R*A
    w[6] = theta_A*D_A_prime
    w[7] = alpha_A*D_A
    w[8] = alphaprime_A*D_A_prime
    w[9] = delta_MA*M_A
    w[10] = beta_A*M_A
    w[11] = theta_R*D_R_prime
    w[12] = alpha_R*D_R
    w[13] = alphaprime_R*D_R_prime
    w[14] = delta_MR*M_R
    w[15] = beta_R*M_R
    return w

def RandExp(lam,N):
    U =  np.random.rand(N)
    X = -1/lam*np.log(1-U)
    return X

def RandDisct(x,p,N):
    cdf = np.cumsum(p)
    U = np.random.rand(N)
    idx = np.searchsorted(cdf, U)
    return x[idx]

def SSA(Initial, StateChangeMat, FinalTime):
   # Inputs:
   #  Initial: initial conditins of size (StateNo x 1)
   #  StateChangeMat: State-change matrix of size (ReactNo, StateNo)
   #  FinalTime: the maximum time we want the process be run

   # Output:
   #  AllTimes: all selected time levels
   #  AllStates: all state values at corresponding time levels

    [m,n] = StateChangeMat.shape
    ReactNum = np.array(range(m))
    AllTimes = {}   # define a dictionary for storing all time levels
    AllStates = {}  # define a dictionary for storing all states at all time levels
    AllStates[0] = Initial
    AllTimes[0] = [0]
    k = 0; t = 0; State = Initial
    while True:
        w = PropensityFunc(State, m)     # propensities
        a = np.sum(w)
        tau = RandExp(a,1)               # WHEN the next reaction happens
        t = t + tau                      # update time
        if t > FinalTime:
            break
        which = RandDisct(ReactNum,w/a,1)             # WHICH reaction occurs
        State = State + StateChangeMat[which.item(),] # Uppdate the state
        k += 1
        AllTimes[k] = t
        AllStates[k] = State
    return AllTimes, AllStates

timeax = np.linspace(0, 400, 1000)
theta_A=50
theta_R=100
gamma_A=1
gamma_R=1
gamma_C=2
alphaprime_A=500
alpha_A=50
alpha_R=0.01
alphaprime_R=50
delta_MA=10
delta_R=0.05
delta_MR=0.5
delta_A=1
beta_A=50
beta_R=5

initial_mat = np.zeros(9)
initial_mat[3] = 1
initial_mat[4] = 1

StateChangeMat = np.array([
                          [-1,  -1, 1, 0, 0, 0, 0, 0 ,0],
                          [-1,  0, 0, 0, 0, 0, 0, 0 ,0],
                          [0,  1, -1, 0, 0, 0, 0, 0 ,0],
                          [0,  -1, 0, 0, 0, 0, 0, 0 ,0],
                          [-1,  0, 0, -1, 0, 1, 0, 0 ,0],
                          [-1,  0, 0, 0, -1, 0, 1, 0 ,0],
                          [1,  0, 0, 1, 0, -1, 0, 0 ,0],
                          [0,  0, 0, 0, 0, 0, 0, 1 ,0],
                          [0,  0, 0, 0, 0, 0, 0, 1 ,0],
                          [0,  0, 0, 0, 0, 0, 0, -1 ,0],
                          [1,  0, 0, 0, 0, 0, 0, 0 ,0],
                          [1,  0, 0, 0, 1, 0, -1, 0 ,0],
                          [0,  0, 0, 0, 0, 0, 0, 0 ,1],
                          [0,  0, 0, 0, 0, 0, 0, 0 ,1],
                          [0,  0, 0, 0, 0, 0, 0, 0 ,-1],
                          [0,  1, 0, 0, 0, 0, 0, 0 ,0], ])

FinalTime = 400

Times, States = SSA(initial_mat, StateChangeMat, FinalTime)

n = len(Times)
t = [Times[i][0] for i in range(n)]
A = [States[i][0] for i in range(n)]
R = [States[i][1] for i in range(n)]

plt.subplot(2,1,1)
plt.plot(t,A,linestyle = '-', color = 'blue',label = 'A')
plt.subplot(2,1,2)
plt.plot(t,R,linestyle = '-', color = 'red',label = 'R')
plt.xlabel('Time')
plt.ylabel('Number of moles')
plt.title('Stochastic solutions using SSA')
plt.legend()
plt.show()